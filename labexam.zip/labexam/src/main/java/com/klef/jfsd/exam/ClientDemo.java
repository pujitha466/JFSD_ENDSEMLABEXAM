package com.klef.jfsd.exam;

import org.hibernate.Session;
import org.hibernate.Transaction;

public class ClientDemo {
    public static void main(String[] args) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction transaction = session.beginTransaction();

        // Create Vehicle
        Vehicle vehicle = new Car();
        vehicle.setName("Generic Vehicle");
        vehicle.setType("General");
        vehicle.setMaxSpeed(100);
        vehicle.setColor("Black");
        session.save(vehicle);

        // Create Car
        Car car = new Car();
        car.setName("Honda Civic");
        car.setType("Car");
        car.setMaxSpeed(220);
        car.setColor("Red");
        car.setNumberOfDoors(4);
        session.save(car);

        // Create Truck
        Truck truck = new Truck();
        truck.setName("Volvo FH");
        truck.setType("Truck");
        truck.setMaxSpeed(150);
        truck.setColor("Blue");
        truck.setLoadCapacity(10000);
        session.save(truck);

        transaction.commit();
        session.close();

        System.out.println("Records inserted successfully!");
    }
}
